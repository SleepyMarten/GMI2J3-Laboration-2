
SQL Server database schema validation, deployment, and upgrade runtime. 
Enables declarative database development and database portability across SQL Server versions and environments.
https://github.com/microsoft/DacFx

Using Advanced Publish Settings
https://www.mssqltips.com/sqlservertip/5456/using-advanced-publish-settings-for-visual-studio-database-project/

How to Create a Database Project in Visual Studio
https://www.youtube.com/watch?v=MC1RFwVT7bw

Start stop msqlserver
https://stackoverflow.com/questions/1161305/how-to-start-stop-local-sql-server-service-directly-from-visual-studio